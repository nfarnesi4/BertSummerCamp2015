var class_red_bot_accel =
[
    [ "RedBotAccel", "class_red_bot_accel.html#ad2d0de0051d6570ab9d0d4f06e7468a9", null ],
    [ "checkBump", "class_red_bot_accel.html#a88e803ce82865fa875e17e85f9e56801", null ],
    [ "enableBump", "class_red_bot_accel.html#a861b1e8f2cd9e35c3b2caee54d43d2d1", null ],
    [ "read", "class_red_bot_accel.html#a2b205e64828e57dcf2fb35ee81d5e731", null ],
    [ "setBumpThresh", "class_red_bot_accel.html#ace6875bab4125392c24c4fecc0313c32", null ],
    [ "x", "class_red_bot_accel.html#a190369eae35db9db9d406dab70ec90ad", null ],
    [ "y", "class_red_bot_accel.html#a1a4efe3197febc4632b8fc48237bb440", null ],
    [ "z", "class_red_bot_accel.html#a8678bd23d5f1913950b5c97b9487a9da", null ]
];