var class_red_bot_motor =
[
    [ "RedBotMotor", "class_red_bot_motor.html#ae2c204ef267fe9bde43cf6caeb693eae", null ],
    [ "brake", "class_red_bot_motor.html#a64540ac32e023eff2c93fd60f0537562", null ],
    [ "drive", "class_red_bot_motor.html#a92a78cd6ecaf47cb50b1c8059375c261", null ],
    [ "leftBrake", "class_red_bot_motor.html#a1fbd19b1b3ef733664397c183bb910ea", null ],
    [ "leftDrive", "class_red_bot_motor.html#aeef7a9abd94a74ea87860163ecad6764", null ],
    [ "leftStop", "class_red_bot_motor.html#ac757e02db079bc5a57774b4c7bbc3737", null ],
    [ "pivot", "class_red_bot_motor.html#a61a73a2dd543697bc966bbb0de47a81d", null ],
    [ "rightBrake", "class_red_bot_motor.html#a710584b709cd8a7a7070cbbf3d0a6ed6", null ],
    [ "rightDrive", "class_red_bot_motor.html#acf1246d90ff26ec68748e16e7d80e78b", null ],
    [ "rightStop", "class_red_bot_motor.html#affb91e6e7205c9df1482bb58f0c0ed05", null ],
    [ "stop", "class_red_bot_motor.html#a2e55b7f88c4c081928370fe711ca61ef", null ]
];