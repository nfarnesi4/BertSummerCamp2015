var searchData=
[
  ['setbglevel',['setBGLevel',['../class_red_bot_sensor.html#aa3e2c32c59f8ac1f9866069602a16eba',1,'RedBotSensor']]],
  ['setbumpthresh',['setBumpThresh',['../class_red_bot_accel.html#ace6875bab4125392c24c4fecc0313c32',1,'RedBotAccel']]],
  ['setdetectlevel',['setDetectLevel',['../class_red_bot_sensor.html#a9bbf93b3c4282562e14f605a07f47c64',1,'RedBotSensor']]],
  ['stop',['stop',['../class_red_bot_motor.html#a2e55b7f88c4c081928370fe711ca61ef',1,'RedBotMotor']]]
];
