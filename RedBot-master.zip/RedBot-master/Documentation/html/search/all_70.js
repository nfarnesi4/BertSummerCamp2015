var searchData=
[
  ['pivot',['pivot',['../class_red_bot_motor.html#a61a73a2dd543697bc966bbb0de47a81d',1,'RedBotMotor']]]
];
